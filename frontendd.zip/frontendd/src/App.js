import logo from './logo.svg';
import './App.css';
import SmartLockDashboard from './SmartLockDashboard';

function App() {
  return (
    <SmartLockDashboard/>
  );
}

export default App;
